# RobotCar SEO 项目资料包

版本：2026-10-16。项目：**RobotCar 技术 SEO 审计与 Google 索引验证**。

先打开 [项目手册.html](项目手册.html)，带目录和章节搜索；也可以阅读 [完整 PDF](RobotCar-SEO项目手册.pdf)。准备简历使用 [可编辑简历稿.docx](RobotCar-SEO简历稿.docx)。

## 推荐顺序

1. [阅读指南](docs/00-阅读指南.md) → [项目现状](docs/01-项目定义与现状.md)。
2. [收录诊断案例](docs/03-收录排障案例与核心原理.md) → [简历与答辩](docs/08-简历与项目答辩.md)。
3. [实操手册](docs/06-复现实操与故障手册.md) → [工具源码学习](docs/10-审计工具源码学习.md)。
4. 按 [六周路线与面试题](docs/07-六周学习路线与面试题.md) 保存自己的练习产物。

## 目录

- `docs/`：11 篇 Markdown 章节，可编辑。
- `tools/`：零第三方依赖的 Python SEO 审计 CLI、15 项 fixture 测试；另有可选文档生成脚本。
- `templates/`：关键词映射、GSC 周记录、实验日志、审计待办、重定向矩阵、内容简报。
- `evidence/static-audit/`：固定提交部署包的 JSON/CSV 报告、校验来源与测试日志。
- `evidence/baseline/`：已提交版本的静态包，可离线解压后复现审计；无须先安装前端环境。
- `evidence/live-2026-10-16/`：本轮公网 GET 和官方文档请求记录；公开 HTML 响应快照。
- `evidence/GSC-人工转录记录.md`：对话截图的文字证据台账，原始截图未打包。
- `assets/`：项目图和已有网站参考图；网站截图不是本轮排名或转化证据。

网站代码入口见 [固定版本源码索引](evidence/源码索引.md)。

## 先跑一个检查

需 Python 3.10 或更新版本，在本目录运行：

```bash
python -m unittest discover -s tools -p 'test_*.py' -v
mkdir -p ./baseline-site
tar -xzf evidence/baseline/robotcar-site-84c4b0c.tar.gz -C ./baseline-site
python tools/seo_audit.py --root ./baseline-site --site https://robotcar.icu --output ./my-audit
```

Windows 可用 `py -3` 替代 `python`。输入必须是已经构建的目录，输出放在输入目录之外。详见 [工具说明](tools/README.md)。

本轮验证：60 个 HTML、55 个公共候选 URL；公共页面在静态链接图上全部可达，最大最短点击深度 2；15 项工具测试通过。**0 硬错误同时有 6 条建议，不能理解为全站 SEO 没有问题。**

网站源码：[shan504/robotdog](https://github.com/shan504/robotdog/tree/84c4b0cef370b66a4e17396c291d21bc2945323d)。本资料包新增工具与文档尚未推送该仓库，没有改站或部署。Google 证据目前只确认首页索引，未提供自然流量、排名提升、CWV、真实销售成果。简历须在亲自学习复现后按实际贡献使用。

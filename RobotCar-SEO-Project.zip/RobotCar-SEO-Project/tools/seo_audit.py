#!/usr/bin/env python3
"""Read-only, standard-library audit of a built static website.

This measures local HTML and link topology. It does not query Google, execute
JavaScript, simulate HTTP headers, measure performance or certify indexing.
"""
from __future__ import annotations

import argparse
import csv
import json
import posixpath
import re
from collections import Counter, deque
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urljoin, urlsplit
import xml.etree.ElementTree as ET

SITEMAP_NS = "http://www.sitemaps.org/schemas/sitemap/0.9"


def file_url_path(relative: str) -> str:
    if relative == "index.html":
        return "/"
    if relative.endswith("/index.html"):
        return "/" + relative[:-10]
    return "/" + relative


def normalize_path(path: str) -> str:
    """Strip URL encoding and dot segments without changing case."""
    decoded = unquote(path or "/")
    normalized = posixpath.normpath("/" + decoded.lstrip("/"))
    if decoded.endswith("/") and normalized != "/":
        normalized += "/"
    return normalized


class Document(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.titles: list[str] = []
        self.descriptions: list[str] = []
        self.canonicals: list[str] = []
        self.robots: list[str] = []
        self.h1: list[str] = []
        self.hrefs: list[str] = []
        self.images = 0
        self.images_missing_alt = 0
        self.images_empty_alt = 0
        self.ld_json: list[str] = []
        self.base_href: str | None = None
        self._capture: str | None = None
        self._parts: list[str] = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in ("title", "h1"):
            self._capture, self._parts = tag, []
        elif tag == "script" and (attrs.get("type") or "").lower() == "application/ld+json":
            self._capture, self._parts = "ld", []
        elif tag == "meta":
            name = (attrs.get("name") or "").lower()
            if name == "description":
                self.descriptions.append(attrs.get("content") or "")
            elif name in ("robots", "googlebot"):
                self.robots.append(attrs.get("content") or "")
        elif tag == "link" and "canonical" in (attrs.get("rel") or "").lower().split():
            self.canonicals.append(attrs.get("href") or "")
        elif tag == "a" and attrs.get("href") is not None:
            self.hrefs.append(attrs["href"])
        elif tag == "img":
            self.images += 1
            if "alt" not in attrs:
                self.images_missing_alt += 1
            elif not (attrs.get("alt") or "").strip():
                self.images_empty_alt += 1
        elif tag == "base" and attrs.get("href") and self.base_href is None:
            self.base_href = attrs["href"]

    def handle_data(self, data):
        if self._capture:
            self._parts.append(data)

    def handle_endtag(self, tag):
        if (tag == self._capture) or (tag == "script" and self._capture == "ld"):
            value = " ".join("".join(self._parts).split()) if self._capture != "ld" else "".join(self._parts)
            if self._capture == "title":
                self.titles.append(value)
            elif self._capture == "h1":
                self.h1.append(value)
            else:
                self.ld_json.append(value)
            self._capture, self._parts = None, []


class Robots:
    """A deliberately bounded User-agent:* longest-prefix policy model."""
    def __init__(self, source: str):
        self.rules: list[tuple[str, bool]] = []
        self.sitemaps: list[str] = []
        self.unsupported: list[str] = []
        agents: list[str] = []
        rules_seen = False
        for raw_line in source.splitlines():
            line = raw_line.split("#", 1)[0].strip()
            if not line or ":" not in line:
                continue
            key, value = (part.strip() for part in line.split(":", 1))
            key = key.lower()
            if key == "user-agent":
                if rules_seen:
                    agents, rules_seen = [], False
                agents.append(value.lower())
            elif key == "sitemap":
                self.sitemaps.append(value)
            elif key in ("allow", "disallow"):
                rules_seen = True
                if "*" not in agents or not value:
                    continue
                if "*" in value or "$" in value:
                    self.unsupported.append(value)
                    continue
                self.rules.append((value, key == "allow"))

    def allowed(self, path: str) -> bool:
        matches = [(len(prefix), allowed) for prefix, allowed in self.rules if path.startswith(prefix)]
        return max(matches, default=(0, True))[1]


def schema_types(value) -> set[str]:
    result: set[str] = set()
    if isinstance(value, dict):
        types = value.get("@type", [])
        if isinstance(types, str):
            result.add(types)
        elif isinstance(types, list):
            result.update(t for t in types if isinstance(t, str))
        for child in value.values():
            result.update(schema_types(child))
    elif isinstance(value, list):
        for child in value:
            result.update(schema_types(child))
    return result


def audit(root: Path, site: str) -> dict:
    root = root.resolve()
    parsed_site = urlsplit(site)
    if parsed_site.scheme not in ("http", "https") or not parsed_site.netloc or parsed_site.path not in ("", "/") or parsed_site.query or parsed_site.fragment or parsed_site.username:
        raise ValueError("--site must be an HTTP(S) origin, e.g. https://robotcar.icu")
    site = f"{parsed_site.scheme}://{parsed_site.netloc}"
    if not root.is_dir():
        raise ValueError(f"Not a directory: {root}")
    issues: list[dict] = []

    def issue(severity: str, code: str, page: str, detail: str):
        issues.append({"severity": severity, "code": code, "page": page, "detail": detail})

    robots_path = root / "robots.txt"
    robots = Robots(robots_path.read_text(encoding="utf-8") if robots_path.exists() else "")
    if not robots_path.exists():
        issue("warning", "ROBOTS_MISSING", "/robots.txt", "No local robots.txt; absence does not itself block crawling.")
    for pattern in robots.unsupported:
        issue("warning", "ROBOTS_PATTERN_UNMODELED", "/robots.txt", f"Wildcard/end-anchor rule requires manual verification: {pattern}")

    pages: dict[str, dict] = {}
    all_files = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    aliases: dict[str, str] = {}
    documents: dict[str, Document] = {}
    for file_name in sorted(f for f in all_files if f.endswith(".html")):
        path = file_url_path(file_name)
        aliases["/" + file_name] = path
        aliases[path] = path
        if path.endswith("/") and path != "/":
            aliases[path[:-1]] = path
        doc = Document()
        try:
            doc.feed((root / file_name).read_text(encoding="utf-8"))
            doc.close()
        except (UnicodeError, ValueError) as exc:
            issue("error", "HTML_READ_ERROR", path, str(exc))
        noindex = any(token.lower() in ("noindex", "none") for directives in doc.robots for token in re.split(r"[\s,]+", directives))
        special = file_name == "404.html" or path == "/404/"
        blocked = not robots.allowed(path)
        page = {
            "path": path, "url": site + path, "file": file_name,
            "title": doc.titles[0] if doc.titles else "",
            "description": doc.descriptions[0] if doc.descriptions else "",
            "canonical": doc.canonicals[0] if doc.canonicals else "",
            "noindex": noindex, "robots_allowed": not blocked,
            "special_404": special, "public_candidate": not noindex and not special,
            "locally_indexable": not noindex and not blocked and not special,
            "h1_count": len(doc.h1), "image_count": doc.images,
            "images_missing_alt": doc.images_missing_alt, "images_empty_alt": doc.images_empty_alt,
            "schema_types": [], "in_sitemap": False, "home_click_depth": None,
            "internal_page_outlinks": 0, "internal_page_inlinks": 0,
        }
        pages[path] = page
        documents[path] = doc
        if len(doc.titles) != 1 or not page["title"]:
            issue("error", "TITLE_INVALID", path, f"Expected one non-empty title; found {len(doc.titles)}.")
        if len(doc.descriptions) != 1 or not page["description"]:
            issue("warning", "DESCRIPTION_INVALID", path, f"Expected one non-empty meta description; found {len(doc.descriptions)}.")
        if special:
            if doc.canonicals and (len(doc.canonicals) != 1 or page["canonical"] != page["url"]):
                issue("warning", "SPECIAL_404_CANONICAL_REVIEW", path, f"Special 404 document declares {doc.canonicals!r}. Its delivery URL depends on the web server; it is excluded from public-page canonical checks.")
        elif len(doc.canonicals) != 1:
            issue("error", "CANONICAL_COUNT", path, f"Expected one canonical; found {len(doc.canonicals)}.")
        elif page["canonical"] != page["url"]:
            issue("error", "CANONICAL_MISMATCH", path, f"Expected {page['url']}, found {page['canonical']!r}.")
        if len(doc.h1) != 1:
            issue("warning", "H1_COUNT", path, f"Expected one primary H1 for this project; found {len(doc.h1)}. This is an editorial check, not a ranking rule.")
        if doc.images_missing_alt:
            issue("warning", "IMAGE_ALT_MISSING", path, f"{doc.images_missing_alt} images omit alt. Empty alt is allowed for decorative images and reported separately.")
        types: set[str] = set()
        for index, raw in enumerate(doc.ld_json, 1):
            try:
                types.update(schema_types(json.loads(raw)))
            except json.JSONDecodeError as exc:
                issue("error", "JSON_LD_INVALID", path, f"Block {index}: {exc.msg}")
        page["schema_types"] = sorted(types)
        if noindex and blocked:
            issue("warning", "NOINDEX_BLOCKED_FROM_CRAWL", path, "robots.txt blocks crawling, so Google may not be able to read this page's HTML noindex. Neither robots exclusion nor noindex is access control.")

    if not pages:
        issue("error", "HTML_NONE", "/", "No .html files found.")

    for field, code in (("title", "TITLE_DUPLICATE"), ("description", "DESCRIPTION_DUPLICATE"), ("canonical", "CANONICAL_DUPLICATE")):
        grouped: dict[str, list[str]] = {}
        for page in pages.values():
            if page["public_candidate"] and page[field]:
                grouped.setdefault(page[field], []).append(page["path"])
        for value, paths in grouped.items():
            if len(paths) > 1:
                issue("error" if field != "description" else "warning", code, ", ".join(paths), f"Shared {field}: {value}")

    sitemap_path = root / "sitemap.xml"
    sitemap_urls: list[str] = []
    if not sitemap_path.exists():
        issue("error", "SITEMAP_MISSING", "/sitemap.xml", "No local sitemap.xml found.")
    else:
        try:
            tree = ET.parse(sitemap_path)
            element = tree.getroot()
            if element.tag != f"{{{SITEMAP_NS}}}urlset":
                issue("error", "SITEMAP_ROOT", "/sitemap.xml", "Expected sitemap-namespace urlset; sitemap indexes are outside this tool's scope.")
            else:
                for item in element.findall(f"{{{SITEMAP_NS}}}url"):
                    locs = item.findall(f"{{{SITEMAP_NS}}}loc")
                    if len(locs) != 1 or not (locs[0].text or "").strip():
                        issue("error", "SITEMAP_LOC_INVALID", "/sitemap.xml", "Each url must contain one non-empty loc.")
                        continue
                    loc = locs[0].text.strip()
                    sitemap_urls.append(loc)
                    target = urlsplit(loc)
                    if target.scheme != parsed_site.scheme or target.netloc != parsed_site.netloc or target.query or target.fragment:
                        issue("error", "SITEMAP_URL_ORIGIN", loc, f"Expected canonical absolute URL under {site}, without query or fragment.")
                        continue
                    normalized = normalize_path(target.path)
                    resolved = aliases.get(normalized)
                    if resolved is None:
                        issue("error", "SITEMAP_TARGET_MISSING", loc, "URL has no corresponding local HTML file.")
                        continue
                    page = pages[resolved]
                    page["in_sitemap"] = True
                    if loc != page["url"]:
                        issue("error", "SITEMAP_NONCANONICAL", loc, f"Canonical local URL is {page['url']}.")
                    if page["noindex"] or page["special_404"]:
                        issue("error", "SITEMAP_NOT_INDEXABLE", loc, "Sitemap includes noindex or special 404 page.")
                    if not page["robots_allowed"]:
                        issue("error", "SITEMAP_ROBOTS_BLOCKED", loc, "Sitemap includes a page blocked by modeled robots.txt policy.")
            for loc, count in Counter(sitemap_urls).items():
                if count > 1:
                    issue("error", "SITEMAP_DUPLICATE_URL", loc, f"Repeated {count} times.")
        except ET.ParseError as exc:
            issue("error", "SITEMAP_XML_INVALID", "/sitemap.xml", str(exc))
    if robots.sitemaps and site + "/sitemap.xml" not in robots.sitemaps:
        issue("warning", "ROBOTS_SITEMAP_DIFFERENT", "/robots.txt", "robots.txt does not advertise the audited canonical sitemap URL.")
    for page in pages.values():
        if page["public_candidate"] and not page["in_sitemap"]:
            issue("warning", "PUBLIC_PAGE_NOT_IN_SITEMAP", page["path"], "Public local HTML page absent from this sitemap. Sitemap inclusion is a discovery aid, not an indexing guarantee.")

    graph: dict[str, set[str]] = {path: set() for path in pages}
    broken: dict[tuple[str, str], set[str]] = {}
    for path, doc in documents.items():
        base = urljoin(site + path, doc.base_href) if doc.base_href else site + path
        for href in doc.hrefs:
            href = href.strip()
            if not href:
                continue
            try:
                absolute = urlsplit(urljoin(base, href))
            except ValueError:
                issue("warning", "LINK_URL_INVALID", path, repr(href))
                continue
            if absolute.scheme not in ("http", "https") or absolute.netloc.lower() != parsed_site.netloc.lower():
                continue
            target_path = normalize_path(absolute.path)
            destination = aliases.get(target_path)
            if destination:
                if destination != path:
                    graph[path].add(destination)
            elif target_path.lstrip("/") not in all_files:
                broken.setdefault((path, target_path), set()).add(href)
    for (path, target), hrefs in sorted(broken.items()):
        issue("error", "INTERNAL_LINK_BROKEN", path, f"Missing local destination {target}; href variants: {sorted(hrefs)}")
    if "/" not in pages:
        issue("error", "HOME_MISSING", "/", "Homepage index.html missing; BFS cannot start.")
    else:
        queue = deque(["/"])
        pages["/"]["home_click_depth"] = 0
        while queue:
            source = queue.popleft()
            for target in sorted(graph[source]):
                if pages[target]["home_click_depth"] is None:
                    pages[target]["home_click_depth"] = pages[source]["home_click_depth"] + 1
                    queue.append(target)
    for source, targets in graph.items():
        pages[source]["internal_page_outlinks"] = len(targets)
        for target in targets:
            pages[target]["internal_page_inlinks"] += 1
    for path, page in pages.items():
        if page["public_candidate"] and page["home_click_depth"] is None:
            issue("warning", "PAGE_UNREACHABLE_FROM_HOME", path, "No path from homepage through static internal a[href] links. Sitemap availability does not replace navigational links.")
        if page["public_candidate"] and page["home_click_depth"] is not None and page["home_click_depth"] > 3:
            issue("warning", "PAGE_CLICK_DEPTH_HIGH", path, f"Shortest static hyperlink path is {page['home_click_depth']} clicks; review importance and navigation, not a Google threshold.")

    public = [p for p in pages.values() if p["public_candidate"]]
    reachable_depths = [p["home_click_depth"] for p in public if p["home_click_depth"] is not None]
    issue_counts = Counter(i["severity"] for i in issues)
    return {
        "tool": "RobotCar Static SEO Audit", "version": "1.0.0",
        "generated_at": datetime.now(timezone.utc).isoformat(), "root": str(root), "site": site,
        "scope": "Local static HTML and a[href] graph; no network, JavaScript execution, headers, real Google indexing/ranking or Core Web Vitals measurement.",
        "summary": {
            "html_pages": len(pages), "public_candidate_pages": len(public),
            "locally_indexable_pages": sum(p["locally_indexable"] for p in pages.values()),
            "noindex_pages": sum(p["noindex"] for p in pages.values()),
            "special_404_pages": sum(p["special_404"] for p in pages.values()),
            "sitemap_url_count": len(sitemap_urls), "sitemap_unique_urls": len(set(sitemap_urls)),
            "public_pages_in_sitemap": sum(p["in_sitemap"] for p in public),
            "unique_public_titles": len({p["title"] for p in public if p["title"]}),
            "unique_public_descriptions": len({p["description"] for p in public if p["description"]}),
            "unique_public_canonicals": len({p["canonical"] for p in public if p["canonical"]}),
            "public_pages_reachable_from_home": len(reachable_depths),
            "public_pages_unreachable_from_home": len(public) - len(reachable_depths),
            "public_click_depth_max": max(reachable_depths, default=None),
            "public_click_depth_histogram": dict(sorted(Counter(reachable_depths).items())),
            "unique_internal_page_edges": sum(map(len, graph.values())),
            "broken_internal_link_pairs": len(broken),
            "image_elements": sum(p["image_count"] for p in pages.values()),
            "image_elements_missing_alt": sum(p["images_missing_alt"] for p in pages.values()),
            "pages_with_json_ld": sum(bool(d.ld_json) for d in documents.values()),
            "schema_types": sorted({t for p in pages.values() for t in p["schema_types"]}),
            "errors": issue_counts["error"], "warnings": issue_counts["warning"],
        },
        "issues": issues,
        "pages": [pages[path] for path in sorted(pages)],
        "internal_link_graph": {source: sorted(targets) for source, targets in sorted(graph.items())},
        "sitemap_urls": sitemap_urls,
        "limitations": [
            "robots.txt models only User-agent:* prefix rules; wildcard and $ rules are reported as unmodeled; specific bot groups and HTTP headers need separate verification.",
            "Click depth follows local static a[href] links, including links through noindex/robots-blocked pages; it is topology, not a Google crawl prediction.",
            "An empty alt may be correct for decorative images. Alt relevance and accessible names are not semantically assessed.",
            "JSON-LD is checked for JSON parseability and discovered @type values; schema vocabulary, required properties and rich-result eligibility are not validated.",
            "Canonical strictness assumes one preferred URL per local static HTML file. Alternate-language or intentionally consolidated duplicates need manual exceptions.",
            "HTTP status, redirects, TLS, response headers, live accessibility, JavaScript routes, canonical selection and actual search visibility are not tested.",
            "No SEO score or traffic uplift is inferred from check counts; warnings require human review.",
        ],
    }


def write_outputs(report: dict, output: Path):
    output.mkdir(parents=True, exist_ok=True)
    (output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    fields = ["path", "file", "title", "description", "canonical", "noindex", "robots_allowed", "special_404", "public_candidate", "locally_indexable", "in_sitemap", "h1_count", "image_count", "images_missing_alt", "images_empty_alt", "schema_types", "home_click_depth", "internal_page_inlinks", "internal_page_outlinks"]
    with (output / "pages.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for page in report["pages"]:
            writer.writerow({**page, "schema_types": ";".join(page["schema_types"])})
    with (output / "issues.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["severity", "code", "page", "detail"])
        writer.writeheader()
        writer.writerows(report["issues"])


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True, help="Static output directory, e.g. dist/")
    parser.add_argument("--site", required=True, help="Canonical origin, e.g. https://robotcar.icu")
    parser.add_argument("--output", type=Path, required=True, help="Directory for report.json, pages.csv and issues.csv")
    args = parser.parse_args(argv)
    try:
        if args.output.resolve() == args.root.resolve() or args.root.resolve() in args.output.resolve().parents:
            parser.error("--output must be outside --root, to keep audited content read-only")
        report = audit(args.root, args.site)
        write_outputs(report, args.output)
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    print(json.dumps(report["summary"], ensure_ascii=False, indent=2))
    print(f"Reports: {args.output.resolve()}")
    return 1 if report["summary"]["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())

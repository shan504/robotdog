#!/usr/bin/env python3
"""Optional documentation builder. Requires pandoc; the audit CLI does not."""
from pathlib import Path
import html
import json
import os
import re
import shutil
import subprocess
from urllib.parse import unquote, urlsplit, quote

ROOT = Path(__file__).resolve().parents[1]
DOCS = sorted((ROOT / 'docs').glob('*.md'))


def rewrite_links(fragment, source):
    def rewrite(match):
        attr, raw = match.group(1), html.unescape(match.group(2))
        url = urlsplit(raw)
        if url.scheme or url.netloc or not url.path:
            return match.group(0)
        target = (source.parent / unquote(url.path)).resolve()
        if target in DOCS:
            value = '#chapter-' + target.name[:2]
        elif target.is_relative_to(ROOT):
            value = quote(os.path.relpath(target, ROOT), safe='/')
            if url.fragment:
                value += '#' + url.fragment
        else:
            return match.group(0)
        return f'{attr}="{html.escape(value, quote=True)}"'
    return re.sub(r'(href|src)="([^"]+)"', rewrite, fragment)


CSS = r'''
@font-face {font-family:ProjectCJK;src:local("Noto Sans CJK SC");font-weight:100 900}
:root{--blue:#1769cf;--ink:#152c46;--muted:#60758c;--line:#d9e3ec;--paper:#fff;--bg:#f2f5f8}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--bg);color:#243b50;font:16px/1.85 ProjectCJK,"Noto Sans CJK SC",sans-serif}
a{color:#1264b9;text-decoration:none;overflow-wrap:anywhere}a:hover{text-decoration:underline}
aside{position:fixed;inset:0 auto 0 0;width:258px;padding:30px 20px;background:#102941;color:#e0ebf4;overflow:auto}
aside .brand{font-size:25px;font-weight:800;letter-spacing:.2px;color:white}aside p{font-size:12px;color:#b4c7d8;line-height:1.7}
aside a{display:block;padding:8px 9px;margin:3px 0;border-radius:5px;color:#e1edf5;font-size:13px;line-height:1.5}aside a:hover{background:#24455e;text-decoration:none}
aside input{width:100%;margin:16px 0 4px;padding:10px 12px;border:1px solid #537086;border-radius:5px;background:#1a3a53;color:white;font:inherit;font-size:13px}aside input::placeholder{color:#b4c7d8}
#search-count{display:block;min-height:24px;font-size:11px;color:#b5cadc}
main{max-width:1120px;margin-left:258px;padding:36px 36px 72px}
.cover{background:linear-gradient(125deg,#102b48,#124c7c);border-radius:12px;padding:46px 42px;color:white;margin-bottom:28px}
.cover .kicker{font-size:12px;letter-spacing:3px;color:#9dc7ea}.cover h1{font-size:35px;line-height:1.5;margin:12px 0 16px;color:#fff}
.cover p{color:#d4e5f2;font-size:15px}.chips{display:flex;flex-wrap:wrap;gap:8px;margin:24px 0}.chip{border:1px solid #5681a3;color:#e2f0fb;border-radius:4px;padding:4px 9px;font-size:12px}
.cover-links{display:flex;gap:16px;flex-wrap:wrap}.cover-links a{color:#fff;border-bottom:1px solid #7eadd0;font-size:13px}
.score-row{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:20px 0}.score{background:white;border:1px solid var(--line);border-top:3px solid var(--blue);border-radius:7px;padding:16px}.score strong{font-size:28px;color:var(--ink);display:block;line-height:1.3}.score span{font-size:12px;color:var(--muted)}
.visual{background:white;border:1px solid var(--line);border-radius:9px;padding:20px;margin-bottom:28px}.visual img{width:100%;height:auto;display:block}.visual p{font-size:12px;color:var(--muted);margin:10px 0 0}
.chapter{background:var(--paper);border:1px solid var(--line);border-radius:9px;margin-bottom:24px;padding:32px 38px;scroll-margin-top:20px}
.chapter>h1{font-size:27px;line-height:1.55;color:#143e62;border-bottom:2px solid #dce9f3;padding-bottom:16px;margin:0 0 24px}
h2{font-size:21px;line-height:1.55;color:#174c76;margin:32px 0 13px}h3{font-size:17px;line-height:1.65;color:#274b68;margin:24px 0 10px}h4{font-size:16px;color:#33566f}
p{margin:12px 0}li{margin:5px 0}strong{color:#143b5b}table{border-collapse:collapse;width:100%;margin:18px 0;table-layout:fixed;font-size:13px;line-height:1.8}th,td{border:1px solid var(--line);padding:10px 11px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#eaf2f8;color:#23465f;font-weight:700}tr:nth-child(even) td{background:#f8fafc}
code{font-family:"Noto Sans Mono CJK SC",monospace;background:#edf3f8;color:#204e70;padding:1px 4px;border-radius:3px;font-size:.86em;overflow-wrap:anywhere}pre{background:#102b42;color:#eef5fc;padding:18px;border-radius:6px;white-space:pre-wrap;word-break:break-word;line-height:1.65;font-size:12px}pre code{background:none;color:inherit;padding:0;font-size:inherit}blockquote{border-left:3px solid #5593c7;background:#f0f6fb;padding:8px 18px;margin:16px 0;color:#435f75}
footer.end{font-size:12px;color:var(--muted);text-align:center;padding:16px}.small{font-size:12px;color:var(--muted)}
@media(max-width:1050px){aside{width:220px}main{margin-left:220px;padding:22px}.chapter{padding:26px}.cover{padding:30px}.cover h1{font-size:28px}}
@media(max-width:740px){aside{position:static;width:auto;padding:20px}aside nav{display:grid;grid-template-columns:1fr 1fr;gap:1px}aside a{font-size:12px}aside .intro{display:none}main{margin:0;padding:14px}.cover{padding:24px}.cover h1{font-size:24px}.score-row{grid-template-columns:1fr 1fr}.chapter{padding:22px 18px}.chapter>h1{font-size:23px}h2{font-size:19px}table{font-size:11px}th,td{padding:7px}pre{font-size:11px}}
@page{size:A4;margin:17mm 15mm 18mm}
@media print{html{scroll-behavior:auto}body{background:white;color:#1d3041;font-size:10pt;line-height:1.75}aside,.cover-links,.no-print{display:none!important}main{margin:0;max-width:none;padding:0}.cover{border-radius:0;min-height:115mm;padding:14mm 11mm;margin:0 0 7mm;break-inside:avoid}.cover h1{font-size:29pt}.cover p{font-size:11pt}.cover .kicker{font-size:9pt}.chips{gap:2mm}.chip{font-size:9pt}.score-row{gap:3mm;margin:5mm 0}.score{padding:4mm;break-inside:avoid}.score strong{font-size:22pt}.score span{font-size:9pt}.visual{padding:4mm;border-radius:0;margin-bottom:5mm;break-inside:avoid}.visual p{font-size:8pt}.chapter,.chapter[hidden]{display:block!important;border:0;border-radius:0;padding:0;margin:0;break-before:page}.chapter>h1{font-size:20pt;padding:0 0 4mm;margin:0 0 6mm}h2{font-size:14pt;margin:7mm 0 3mm;break-after:avoid}h3{font-size:11.5pt;break-after:avoid}p{orphans:3;widows:3}table{font-size:8pt;line-height:1.65;margin:4mm 0}th,td{padding:2mm;overflow-wrap:anywhere}tr{break-inside:avoid}thead{display:table-header-group}pre{font-size:8pt;line-height:1.65;border:1px solid #cbdbe7;background:#eef4f8;color:#213c51;break-inside:auto;padding:3mm}code{font-size:.88em}a{color:#235b85}blockquote{break-inside:avoid}.small,footer.end{font-size:8pt}li{margin:1.4mm 0}}
'''


def main():
    if not shutil.which('pandoc'):
        raise SystemExit('Rebuilding the handbook requires pandoc. The SEO audit tool has no such dependency.')
    nav, chapters = [], []
    for source in DOCS:
        content = source.read_text(encoding='utf-8')
        title = content.splitlines()[0].lstrip('# ').strip()
        key = source.name[:2]
        fragment = subprocess.run(['pandoc', '--from=gfm', '--to=html5', '--wrap=none', str(source)], capture_output=True, text=True, check=True).stdout
        fragment = rewrite_links(fragment, source)
        nav.append(f'<a href="#chapter-{key}">{html.escape(title)}</a>')
        chapters.append(f'<article class="chapter" id="chapter-{key}" data-title="{html.escape(title,quote=True)}">{fragment}</article>')
    audit = json.loads((ROOT/'evidence/static-audit/report.json').read_text(encoding='utf-8'))
    score = audit['summary']
    header = '''<section class="cover"><div class="kicker">ROBOTCAR · SEO PROJECT LAB</div><h1>技术 SEO 审计<br>与 Google 索引验证</h1><p>从一个真实静态网站出发，把源码规则、自动检查和搜索平台证据串成可复现的个人项目。</p><div class="chips"><span class="chip">项目分析</span><span class="chip">简历与答辩</span><span class="chip">可运行工具</span><span class="chip">六周学习路线</span></div><p>2026.10.16 ｜ 源码基线 84c4b0c<br>Python · Astro · BFS · Nginx · Search Console</p><div class="cover-links"><a href="RobotCar-SEO项目手册.pdf">下载完整 PDF</a><a href="RobotCar-SEO简历稿.docx">打开可编辑简历稿</a><a href="README.md">资料包说明</a></div></section>'''
    cards = '<section class="score-row">'+''.join(f'<div class="score"><strong>{value}</strong><span>{label}</span></div>' for value,label in [(score['html_pages'],'静态 HTML 页面'),(score['public_candidate_pages'],'公共候选 URL'),(score['public_click_depth_max'],'首页最短点击深度上限'),('15','工具 fixture 测试通过')])+'</section>'
    visual = '<section class="visual"><img src="assets/project-map.svg" alt="项目链路：源码与静态产物、技术审计、公网访问、Google索引、待积累的搜索业务表现"><p>工程检查、索引状态、搜索展示与业务结果分层验证。55 个公共 URL 不等于 55 页已收录；后续增长指标尚待真实数据。</p></section>'
    js = '''const input=document.getElementById('chapter-search');const sections=[...document.querySelectorAll('.chapter')];input.addEventListener('input',()=>{const q=input.value.trim().toLowerCase();let n=0;for(const s of sections){const ok=!q||s.textContent.toLowerCase().includes(q);s.hidden=!ok;if(ok)n++;}document.getElementById('search-count').textContent=q?`匹配 ${n} / ${sections.length} 章`:'';});document.querySelectorAll('aside nav a').forEach(a=>a.addEventListener('click',()=>{input.value='';sections.forEach(s=>s.hidden=false);document.getElementById('search-count').textContent='';}));'''
    out = f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>RobotCar SEO 项目手册 · 2026-10-16</title><style>{CSS}</style></head><body><aside><div class="brand">RobotCar / SEO</div><p class="intro">项目、代码、证据与学习资料<br>独立资料包 · 不修改线上网站</p><label for="chapter-search">搜索章节内容</label><input id="chapter-search" type="search" placeholder="例如：canonical、简历、BFS"><span id="search-count" aria-live="polite"></span><nav>{''.join(nav)}</nav><p>源码与实测日期详见各章。<br>工具与模板可在 ZIP 中独立使用。</p></aside><main>{header}{cards}{visual}{''.join(chapters)}<footer class="end">RobotCar SEO Project · 2026-10-16 · 以实际检查与学习记录为准</footer></main><script>{js}</script></body></html>'''
    (ROOT/'项目手册.html').write_text(out,encoding='utf-8')
    print(f'HTML generated: {len(DOCS)} chapters, {len(out):,} characters')


if __name__ == '__main__':
    main()

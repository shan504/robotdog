#!/usr/bin/env python3
"""Build the editable two-page RobotCar project resume material.

Usage: python tools/build_resume_docx.py
Requires: python-docx (documentation generation only).
The separate SEO audit CLI uses Python's standard library only.
Source narrative: docs/08-简历与项目答辩.md, evidence date 2026-10-16.
"""

from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "RobotCar-SEO简历稿.docx"
FONT = "Noto Sans CJK SC"
INK = "172A3A"
ACCENT = "216A78"
MUTED = "52616B"


def font(run, size=None, bold=None, color=None):
    run.font.name = FONT
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), FONT)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    return run


def para(document, text="", *, size=11, bold=False, color=INK, before=0, after=5):
    p = document.add_paragraph()
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.15
    font(p.add_run(text), size, bold, color)
    return p


def label(document, text):
    p = para(document, text, size=12, bold=True, color=ACCENT, before=8, after=6)
    p.paragraph_format.keep_with_next = True
    return p


def bullet(document, title, text):
    p = document.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.keep_together = True
    font(p.add_run(title), 11, True, INK)
    font(p.add_run(text), 11, False, INK)
    return p


def hyperlink(p, text, target):
    link = OxmlElement("w:hyperlink")
    rel_id = p.part.relate_to(
        target,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
        is_external=True,
    )
    link.set(qn("r:id"), rel_id)
    run = OxmlElement("w:r")
    props = OxmlElement("w:rPr")
    fonts = OxmlElement("w:rFonts")
    fonts.set(qn("w:ascii"), FONT)
    fonts.set(qn("w:hAnsi"), FONT)
    fonts.set(qn("w:eastAsia"), FONT)
    props.append(fonts)
    color = OxmlElement("w:color")
    color.set(qn("w:val"), ACCENT)
    props.append(color)
    size = OxmlElement("w:sz")
    size.set(qn("w:val"), "19")
    props.append(size)
    run.append(props)
    node = OxmlElement("w:t")
    node.text = text
    run.append(node)
    link.append(run)
    p._p.append(link)


def main():
    doc = Document()
    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(1.7)
    section.bottom_margin = Cm(1.7)
    section.left_margin = Cm(1.8)
    section.right_margin = Cm(1.8)
    section.header_distance = Cm(0.65)
    section.footer_distance = Cm(0.65)

    normal = doc.styles["Normal"]
    normal.font.name = FONT
    normal.font.size = Pt(11)
    normal._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), FONT)
    normal.paragraph_format.line_spacing = 1.15
    for style_name in ("List Bullet",):
        st = doc.styles[style_name]
        st.font.name = FONT
        st.font.size = Pt(11)
        st._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), FONT)

    header = section.header.paragraphs[0]
    font(header.add_run("ROBOTCAR  /  项目简历与答辩素材"), 8, False, MUTED)
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    font(footer.add_run("资料版本 2026-10-16  ·  "), 8, False, MUTED)
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    footer._p.append(field)

    doc.core_properties.title = "RobotCar 技术 SEO 审计与 Google 索引验证 — 简历项目素材"
    doc.core_properties.subject = "个人实践项目；技术 SEO、Python 审计、链接图与索引验证"
    doc.core_properties.author = "RobotCar 项目资料"
    doc.core_properties.comments = "根据 docs/08-简历与项目答辩.md 生成。工程结果与 Google 索引证据分开表述。"

    para(doc, "RobotCar 技术 SEO 审计\n与 Google 索引验证", size=21, bold=True, after=8)
    para(doc, "个人实践项目  |  2026.10  |  推荐方向：技术 SEO / SEO 运营", size=10, color=MUTED, after=5)
    links = doc.add_paragraph()
    links.paragraph_format.space_after = Pt(7)
    hyperlink(links, "网站 robotcar.icu", "https://robotcar.icu/")
    font(links.add_run("   ·   "), 9.5, color=MUTED)
    hyperlink(links, "GitHub shan504/robotdog", "https://github.com/shan504/robotdog")
    para(doc, "仓库保留历史名称 robotdog；当前网站品牌与内容为 RobotCar。", size=9, color=MUTED, after=8)

    label(doc, "推荐简历稿｜学习复现后，按真实参与程度使用")
    para(doc, "Python 标准库 · HTMLParser · URL 归一化 · BFS · JSON/CSV · Search Console", size=9.5, color=MUTED, after=10)

    bullet(doc, "自动化审计：", "协作构建零第三方依赖的 Python SEO 审计 CLI，提取元数据、canonical、robots、JSON-LD 和站内链接，输出逐页 JSON/CSV；15 项 fixture 测试覆盖错误 canonical、孤立页、断链及地图异常。")
    bullet(doc, "站点结构分析：", "审计已提交版本的 60 个静态 HTML，核对 55 个公共 URL 的 Sitemap 覆盖及标题、描述和 canonical 唯一性；通过 URL 归一化与 BFS 确认公共页从首页全部可达，最大最短点击深度为 2。")
    bullet(doc, "公网可用性验证：", "对线上 Sitemap 的 55 个 URL 逐页 GET，HTTP 200、self canonical 与 index/follow 声明均通过；另核验首页变体 301 和未知路径 404，保存带日期的原始报告。")
    bullet(doc, "索引诊断与复盘：", "结合用户 Search Console 证据确认首页已索引、移动 Googlebot 抓取成功与规范网址一致；记录 robots/noindex 冲突等 6 条待复核建议，区分可抓取、已索引与实际搜索展示。")

    label(doc, "项目结果如何解释")
    para(doc, "工程结果是可复现的审计工具、报告和页面检查；搜索引擎侧的已知结果是首页完成索引验证。55 页 HTTP 检查通过不代表全部被 Google 收录，点击深度也不代表 Googlebot 的实际抓取路径。", size=10, color=MUTED, after=6)
    para(doc, "当前没有经过核验的流量、排名、营收或 Core Web Vitals 提升数据。新增审计工具与本文档尚未推送 GitHub，本轮未修改或部署网站。", size=10, color=MUTED, after=0)

    doc.add_page_break()
    para(doc, "可选表述与使用说明", size=19, bold=True, after=5)
    para(doc, "择一使用，不需要把两个版本全部放入简历。", size=10, color=MUTED, after=8)

    label(doc, "前端 / 网站开发岗｜三条压缩版")
    para(doc, "项目名：RobotCar 玩具车展示站｜静态内容架构与 SEO 工程实践", size=10, bold=True, after=7)
    bullet(doc, "静态内容架构：", "参与 Astro 结构化数据驱动的页面实践，将商品配置、配件、应用方案和文章输出为 60 个静态 HTML，主要内容与链接直接存在于 HTML。")
    bullet(doc, "质量检查工具：", "协作实现 Python 标准库 SEO CLI，通过 HTMLParser、XML 解析、URL 归一化与 BFS 生成逐页审计报告，并用 15 项 fixture 测试验证关键异常及输入只读性。")
    bullet(doc, "域名与索引验证：", "复盘统一 SEO 布局和 Nginx 入口归并，核验公共页元数据、canonical、站内可达性及线上响应；结合 Search Console 记录确认首页已索引，并区分本地检查与 Google 处理结果。")

    label(doc, "30 秒项目介绍")
    para(doc, "“我以 RobotCar 展示站做技术 SEO 实践，协作实现 Python 审计工具，通过 HTMLParser、URL 归一化和 BFS 检查静态产物并输出报告。公共页的站内可达性和线上响应已核验，工具有失败场景测试，首页另有 Search Console 已索引证据。这个项目的重点是把 SEO 规则转成可运行检查，再用独立证据验证；流量与排名增长仍待真实数据评估。”", size=11, after=6)

    label(doc, "写入简历前的三步")
    para(doc, "1. 亲自运行审计 CLI 与 fixture 测试，说明 BFS、URL 归一化、canonical 和 robots/noindex 的作用及边界。\n2. 保存自己带日期的复现报告，讲清一条发现、验证与处理建议；只有首页有已知索引证据。\n3. 按真实贡献使用“参与 / 协作实现 / 复盘”，如实说明 AI 辅助；能独立解释和维护后再调整职责动词。", size=10, after=6)

    label(doc, "配套资料与证据入口")
    para(doc, "完整讲稿与追问：docs/08-简历与项目答辩.md\n审计工具与测试：tools/seo_audit.py、tools/test_seo_audit.py\n静态审计原始报告：evidence/static-audit/report.json、fixture-tests.txt\n公网逐页报告：evidence/live-2026-10-16/public-pages.json\n首页索引证据转录：evidence/GSC-人工转录记录.md", size=9.5, color=MUTED, after=5)
    para(doc, "工程审计日期：2026-10-16；用户 GSC 索引记录日期：2026-10-15。站点源码核查基线为 84c4b0c；新增工具和资料位于本次资料包。", size=9, color=MUTED, after=0)

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()

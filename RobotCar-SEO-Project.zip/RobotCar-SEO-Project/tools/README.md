# RobotCar 静态 SEO 审计工具

这是本项目配套的可运行工程成果：一个 **Python 3 标准库、零第三方依赖、零网络请求、只读输入目录** 的审计 CLI。它能把技术 SEO 检查变成可复现报告，适合深入学习 URL 归一化、robots 规则、站点地图、HTML 元数据、链接图与 BFS。

它验证本地静态产物，**不证明 Google 已收录这些页面，不测搜索排名，不测 Core Web Vitals，也不提供“SEO 得分”**。

## 快速运行

在资料包根目录运行（Python 3.10 或以上）：

```bash
python tools/seo_audit.py --root /path/to/static-output --site https://robotcar.icu --output /path/to/audit-output
python -m unittest discover -s tools -p 'test_*.py' -v
```

Windows 可用 `py -3` 替代 `python`。假设网站仓库与资料包都在本地：

```powershell
py -3 tools/seo_audit.py --root C:\projects\robotdog\dist --site https://robotcar.icu --output C:\projects\robotcar-audit
py -3 -m unittest discover -s tools -p "test_*.py" -v
```

`--root` 是已经生成的静态网站目录，里面应有 `index.html`、`robots.txt`、`sitemap.xml`；不是 Astro 的 `src` 目录。工具不会自动构建，也不会上传到服务器。`--output` 必须放在输入目录外，避免污染被审计的静态产物。

退出码：`0` 表示本工具未发现硬错误，仍可能有建议；`1` 表示发现硬错误；`2` 表示参数、文件读取或运行条件不满足。**退出码 0 不等于搜索引擎审核通过。**

输出文件：

| 文件 | 用途 |
| --- | --- |
| `report.json` | 完整指标、每页结果、问题列表、内部链接邻接表及局限 |
| `pages.csv` | 逐页 title / description / canonical / noindex / 深度 / 入链出链等，可用 Excel 查看 |
| `issues.csv` | 问题及建议，方便分配负责人和记录处理状态 |

CSV 采用 UTF-8 BOM，方便 Windows Excel 正确显示中文。审计时间写入 `generated_at`；它不是页面更新时间。

## 实际基线结果

本次证据使用已提交版本 `84c4b0cef370b66a4e17396c291d21bc2945323d` 的 `deploy/robotcar-site.tar.gz`，隔离提取到 `/tmp/robotcar-seo-baseline` 后执行，**没有包含工作区未发布的 Cargo 文案修改**。校验值与来源在 [provenance.json](../evidence/static-audit/provenance.json)，机器报告在 [report.json](../evidence/static-audit/report.json)。

| 指标 | 本次实际值 | 正确解释 |
| --- | ---: | --- |
| 静态 HTML | 60 | 包含交易演示页面与 404 |
| 公共候选页面 | 55 | 排除 4 个交易页与 1 个 404；不是 Google 收录数 |
| Sitemap 唯一 URL | 55 | 55 个公共候选页均在地图内 |
| 公共 title / description / canonical 唯一值 | 各 55 | 元数据去重通过，不代表正文足够独特 |
| 从首页静态链接可达的公共页 | 55 / 55 | 基于构建后的 `<a href>` 图 |
| 公共页面最大最短点击深度 | 2 | 首页 1 页、1 跳 16 页、2 跳 38 页 |
| 去重站内页面有向边 | 934 | 同一来源到同一目标的重复导航只计一次；不含自链接 |
| 站内链接缺失目标对 | 0 | 只验证本地文件，不验证线上状态码和片段 ID |
| `<img>` 元素 / 缺失 alt 属性 | 629 / 0 | 是跨页面元素数，不是 629 张独立素材；空 alt 可能适合装饰图 |
| 含 JSON-LD 的 HTML 页面 | 53 | 解析通过，不代表通过富结果资格验证 |
| 硬错误 / 建议 | 0 / 6 | 建议详情如下，不能写“全站没有任何 SEO 问题” |

这 6 条建议为：

1. `/checkout/`、`/orders/`、`/orders/success/`、`/payment/` 同时使用 HTML `noindex` 与 robots 阻挡，产生 **4 条**“爬虫可能读不到 noindex”的建议。如果目标是删除索引，需要允许爬虫读取 `noindex`；如果是保护隐私，需要鉴权，robots 与 noindex 都不是安全控制。本工具只报告，没有改生产策略。
2. `/orders/success/` 有 **2 个 H1**，产生 1 条内容结构建议。单个 H1 是本项目编辑约定，不是 Google 的一条排名处罚规则。
3. 特殊错误文件 `/404.html` 声明 canonical 为 `https://robotcar.icu/404/`，产生 1 条复核建议。404 的实际投递 URL 取决于服务器，本工具不会将该非公开错误文档混入 55 个公共页面的 canonical 硬性校验。

发现的 JSON-LD 类型包括 `Organization`、`BreadcrumbList`、`Article`，以及其内部的 `ListItem`。`ListItem` 是嵌套节点，不是独立的 Google 富结果承诺。没有把 `Product` / `Offer` 当作已实现内容。

## 检查规则与阅读代码的顺序

1. `Document`：使用 `HTMLParser` 提取 title、description、canonical、H1、robots、a[href]、img alt、JSON-LD。
2. `file_url_path` 与 `normalize_path`：把 `index.html` 对应到 `/`，把目录的 `index.html` 对应到 `/dir/`；查询串与片段不作为新页面。`/dir/`、`/dir`、`/dir/index.html` 在本地页面图中归为一个节点。
3. `Robots`：只模拟 `User-agent: *` 的简单路径前缀规则。最长匹配获胜，相同长度 `Allow` 获胜。不支持的 `*` / `$` 路径模式会明确报告，不能当作已验证。
4. `audit` 的页面段：要求公共页面独立、绝对、与目标来源及静态路径一致的 self canonical；发现重复元数据与基础 HTML 问题。
5. `audit` 的地图段：校验 XML 命名空间、URL 来源、重复 URL、目标文件存在、noindex / robots 冲突，以及公共页面遗漏。
6. `audit` 的链接段：解析静态内部链接，去掉查询串与 hash，检查本地目标存在；通过队列执行 BFS 计算从首页出发的最短点击深度。
7. `write_outputs` 与 `main`：生成可复核的 JSON / CSV，返回适合自动检查的退出码。

示意：`首页 → 产品列表 → 产品详情` 的深度为 2。即便把详情 URL 放进 sitemap，如果首页没有任何静态链接路径通到它，BFS 仍会报告不可达。这有助于区分 **站点地图发现** 与 **站内导航发现**。

图论复杂度：解析完成后的 BFS 为 `O(V + E)`；此处 `V` 是 HTML 节点数、`E` 是去重页面链接数。HTML 扫描与元数据检查的工作量主要取决于输入文件总字节数。

## Fixture 测试证明什么

`test_seo_audit.py` 有 **15 个通过的测试**，使用临时目录和人工合成的小网站，验证：

- 正常两页站、JSON-LD 与装饰性空 alt；
- canonical 错域名、错路径与特殊 404 的建议级别；
- noindex 进入地图、robots 阻挡 noindex、交易页与 404 正确排除；
- query / fragment / index 别名去重，断链重复变体归并；
- sitemap 内仍可存在首页链接不可达的孤立页；
- 非法 XML、地图错域名、缺失目标、重复地图 URL；
- 重复 title / description、JSON-LD 语法错误与缺失 alt；
- robots 最长匹配、Allow 同长度优先与特定爬虫组的模型边界；
- CLI 输出成功，审计前后输入文件字节保持一致。

测试使用的坏例子是为了证明检测器会报错，**不代表真实网站具有这些错误**。运行网站审计后，应单独查看真实 `issues.csv`。

## 适合继续做的练习

1. 复制一个静态产物到练习目录，故意把一个详情页 canonical 写成旧域名，运行并找到对应错误；恢复后确认错误消失。
2. 从首页与所有列表页去掉某个产品的入口，保留 sitemap URL，观察 `PAGE_UNREACHABLE_FROM_HOME`。只改练习副本。
3. 对 noindex 页做两组 robots 规则，解释“禁止抓取”和“禁止索引”的区别；不要直接把规则同步到生产环境。
4. 增加 `@graph`、图片关联与 Article 必填字段的业务验证，再写真实失败场景的测试。基础解析不能替代 Google Rich Results Test。
5. 后续扩展线上 HTTP 状态码、重定向链、X-Robots-Tag、移动页面渲染、PageSpeed / CrUX。将线上检测与本工具分开，记录访问时间与环境，不复用本地报告声称线上全通过。

## 已知局限

- 不联网、不执行 JS、不知道 DNS/TLS/重定向/缓存/线上响应头；局部成功不能覆盖服务器部署风险。
- 不查询 Search Console 或 Google 搜索，不提供经典搜索排名，更不能证明“前两页”或“55 页都已收录”。
- 不测 LCP、INP、CLS，也不测真实用户行为、GA4 转化或成交金额。
- 内部链接图只读取静态 `<a href>`，不验证锚点是否存在、脚本交互路由、表单提交或外部网址。
- 本地 URL 归并不是服务器重定向验证。线上 `/products` 是否正确跳到 `/products/` 必须另测。
- robots 只覆盖本项目简单通配爬虫组；复杂通配路径、特定 Googlebot 组与 HTTP 响应头需要人工或其他专用解析器。
- BFS 统计静态链接拓扑，也可能穿过 noindex / robots 阻挡页；它不是 Googlebot 的实际爬取路线。
- canonical 按本项目“一页一首选地址”策略校验；多语言或主动合并近似页面需要调整业务规则。
- 文本独特性、关键词意图、产品参数真实性、视觉素材准确性、语义重复内容与 alt 是否合理，需要人工核验。

可以将它介绍为“为 60 页静态站构建可复现的 SEO 审计与链接图检查工具，15 项 fixture 测试覆盖关键失败场景”。不要把这一工程产出改写为未经测量的自然流量增长。

## 可选：更新学习文档的排版文件

`build_handbook.py` 读取 docs/，调用 pandoc 生成带目录和搜索的 HTML；修改后可在浏览器打印保存为 PDF。`build_resume_docx.py` 生成可编辑简历素材，需要 python-docx。它们只用于文档，均不是运行 SEO 审计的前置依赖。

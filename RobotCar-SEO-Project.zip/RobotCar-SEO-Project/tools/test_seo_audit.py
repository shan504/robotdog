"""Synthetic fixtures prove detector behavior, not the website's SEO outcome."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from xml.sax.saxutils import escape

from seo_audit import audit, main, Robots

SITE = "https://robotcar.icu"


def html(path="/", title=None, description=None, links=(), noindex=False, canonical=None, extra="", h1="Page"):
    title = title if title is not None else "Title " + path
    description = description if description is not None else "Description " + path
    return f'''<!doctype html><html><head><title>{escape(title)}</title>
    <meta name="description" content="{escape(description)}">
    <meta name="robots" content="{'noindex,follow' if noindex else 'index,follow'}">
    <link rel="canonical" href="{escape(canonical if canonical is not None else SITE + path)}">
    </head><body><h1>{escape(h1)}</h1>{''.join('<a href="' + escape(x) + '">Link</a>' for x in links)}{extra}</body></html>'''


class AuditFixtures(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name) / "site"
        self.root.mkdir()
        self.write("robots.txt", "User-agent: *\nAllow: /\nSitemap: " + SITE + "/sitemap.xml\n")

    def tearDown(self):
        self.temporary.cleanup()

    def write(self, path, text):
        target = self.root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")

    def sitemap(self, paths):
        self.write("sitemap.xml", '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + ''.join('<url><loc>' + escape(SITE + path) + '</loc></url>' for path in paths) + '</urlset>')

    def report(self):
        return audit(self.root, SITE)

    def codes(self, report):
        return [entry["code"] for entry in report["issues"]]

    def test_valid_two_page_site_with_schema_and_decorative_alt(self):
        self.write("index.html", html(links=["/product/"], extra='<img src="x.webp" alt=""><script type="application/ld+json">{"@context":"https://schema.org","@type":"Organization","name":"Example"}</script>'))
        self.write("product/index.html", html("/product/", links=["/"]))
        self.sitemap(["/", "/product/"])
        report = self.report()
        self.assertEqual(report["summary"]["errors"], 0)
        self.assertEqual(report["summary"]["warnings"], 0)
        self.assertEqual(report["summary"]["public_pages_reachable_from_home"], 2)
        self.assertEqual(report["summary"]["public_click_depth_max"], 1)
        self.assertEqual(report["summary"]["schema_types"], ["Organization"])
        self.assertEqual(report["pages"][0]["images_empty_alt"], 1)

    def test_canonical_wrong_host_is_error(self):
        self.write("index.html", html(canonical="https://old.example/"))
        self.sitemap(["/"])
        self.assertIn("CANONICAL_MISMATCH", self.codes(self.report()))

    def test_canonical_wrong_path_is_error(self):
        self.write("index.html", html(canonical=SITE + "/products/"))
        self.sitemap(["/"])
        self.assertIn("CANONICAL_MISMATCH", self.codes(self.report()))

    def test_special_noindex_404_canonical_is_advisory(self):
        self.write("index.html", html())
        self.write("404.html", html("/404.html", noindex=True, canonical=SITE + "/404/"))
        self.sitemap(["/"])
        report = self.report()
        self.assertIn("SPECIAL_404_CANONICAL_REVIEW", self.codes(report))
        self.assertEqual(report["summary"]["errors"], 0)

    def test_noindex_in_sitemap_and_robots_conflict(self):
        self.write("index.html", html(links=["/checkout/"]))
        self.write("checkout/index.html", html("/checkout/", noindex=True))
        self.write("robots.txt", "User-agent: *\nAllow: /\nDisallow: /checkout/\n")
        self.sitemap(["/", "/checkout/"])
        codes = self.codes(self.report())
        self.assertIn("SITEMAP_NOT_INDEXABLE", codes)
        self.assertIn("SITEMAP_ROBOTS_BLOCKED", codes)
        self.assertIn("NOINDEX_BLOCKED_FROM_CRAWL", codes)

    def test_noindex_transaction_excluded_from_sitemap_and_404_special(self):
        self.write("index.html", html(links=["/checkout/"]))
        self.write("checkout/index.html", html("/checkout/", noindex=True))
        self.write("404.html", html("/404.html", noindex=True))
        self.sitemap(["/"])
        report = self.report()
        self.assertEqual(report["summary"]["public_candidate_pages"], 1)
        self.assertEqual(report["summary"]["noindex_pages"], 2)
        self.assertEqual(report["summary"]["special_404_pages"], 1)
        self.assertEqual(report["summary"]["errors"], 0)
        self.assertNotIn("PUBLIC_PAGE_NOT_IN_SITEMAP", self.codes(report))

    def test_query_fragment_and_index_aliases_do_not_duplicate_graph_edges(self):
        self.write("index.html", html(links=["/product/?sort=price", "/product/#specs", "/product/index.html", "/product", "#top", "mailto:a@example.com", "https://external.example/missing"]))
        self.write("product/index.html", html("/product/"))
        self.sitemap(["/", "/product/"])
        report = self.report()
        self.assertEqual(report["summary"]["unique_internal_page_edges"], 1)
        self.assertEqual(report["internal_link_graph"]["/"], ["/product/"])
        self.assertEqual(report["summary"]["broken_internal_link_pairs"], 0)
        self.assertEqual(report["summary"]["errors"], 0)

    def test_missing_target_variants_report_one_broken_pair(self):
        self.write("index.html", html(links=["/missing/?a=1", "/missing/#a", "/file.pdf"]))
        self.sitemap(["/"])
        report = self.report()
        self.assertEqual(report["summary"]["broken_internal_link_pairs"], 2)
        self.assertEqual(self.codes(report).count("INTERNAL_LINK_BROKEN"), 2)

    def test_orphan_not_reachable_even_when_in_sitemap(self):
        self.write("index.html", html())
        self.write("orphan/index.html", html("/orphan/", links=["/"]))
        self.sitemap(["/", "/orphan/"])
        report = self.report()
        self.assertEqual(report["summary"]["public_pages_unreachable_from_home"], 1)
        self.assertIn("PAGE_UNREACHABLE_FROM_HOME", self.codes(report))

    def test_invalid_xml_is_error_without_crash(self):
        self.write("index.html", html())
        self.write("sitemap.xml", "<urlset><url></urlset>")
        self.assertIn("SITEMAP_XML_INVALID", self.codes(self.report()))

    def test_duplicate_public_metadata_is_reported(self):
        self.write("index.html", html(title="Same", description="Same", links=["/product/"]))
        self.write("product/index.html", html("/product/", title="Same", description="Same"))
        self.sitemap(["/", "/product/"])
        codes = self.codes(self.report())
        self.assertIn("TITLE_DUPLICATE", codes)
        self.assertIn("DESCRIPTION_DUPLICATE", codes)

    def test_invalid_json_ld_and_missing_alt(self):
        self.write("index.html", html(extra='<img src="x.webp"><script type="application/ld+json">{bad}</script>'))
        self.sitemap(["/"])
        codes = self.codes(self.report())
        self.assertIn("JSON_LD_INVALID", codes)
        self.assertIn("IMAGE_ALT_MISSING", codes)

    def test_longest_prefix_allow_tie_and_specific_agent_ignored(self):
        policy = Robots("User-agent: OtherBot\nDisallow: /\nUser-agent: *\nDisallow: /private/\nAllow: /private/public/\nDisallow: /same/\nAllow: /same/\n")
        self.assertTrue(policy.allowed("/"))
        self.assertFalse(policy.allowed("/private/secret/"))
        self.assertTrue(policy.allowed("/private/public/docs/"))
        self.assertTrue(policy.allowed("/same/a/"))

    def test_sitemap_missing_target_external_and_duplicates(self):
        self.write("index.html", html())
        self.write("sitemap.xml", '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>https://elsewhere.example/</loc></url><url><loc>' + SITE + '/missing/</loc></url><url><loc>' + SITE + '/</loc></url><url><loc>' + SITE + '/</loc></url></urlset>')
        codes = self.codes(self.report())
        self.assertIn("SITEMAP_URL_ORIGIN", codes)
        self.assertIn("SITEMAP_TARGET_MISSING", codes)
        self.assertIn("SITEMAP_DUPLICATE_URL", codes)

    def test_cli_writes_reports_and_does_not_mutate_input(self):
        self.write("index.html", html())
        self.sitemap(["/"])
        before = {p.relative_to(self.root).as_posix(): p.read_bytes() for p in self.root.rglob("*") if p.is_file()}
        output = Path(self.temporary.name) / "reports"
        with contextlib.redirect_stdout(io.StringIO()):
            code = main(["--root", str(self.root), "--site", SITE, "--output", str(output)])
        self.assertEqual(code, 0)
        self.assertEqual(json.loads((output / "report.json").read_text())["summary"]["html_pages"], 1)
        self.assertTrue((output / "pages.csv").exists())
        self.assertTrue((output / "issues.csv").exists())
        after = {p.relative_to(self.root).as_posix(): p.read_bytes() for p in self.root.rglob("*") if p.is_file()}
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main(verbosity=2)
